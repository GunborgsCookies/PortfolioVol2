import * as THREE from "three";
import { sceneManager } from "./sceneManager";

// Scene & camera
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.z = 5;

// Renderer
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);

// 🔥 FIX: hindra canvas från att täcka allt
renderer.domElement.style.position = "absolute";
renderer.domElement.style.zIndex = "0";

document.getElementById("app").appendChild(renderer.domElement);

const clock = new THREE.Clock();

// Exportera för scener
export { scene, camera, renderer, clock };

// Starta första scen
sceneManager.start("intro");

// ✅ Animate loop – här lägger vi in scroll-kontrollen
function animate() {
  requestAnimationFrame(animate);

  // 🛑 Stoppa animationer när man scrollat förbi hero (100vh)
  const scrollLimit = window.innerHeight;
  if (window.scrollY <= scrollLimit) {
    sceneManager.update(clock.getElapsedTime());
  }

  renderer.render(scene, camera);
}
animate();

// Responsivitet
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
