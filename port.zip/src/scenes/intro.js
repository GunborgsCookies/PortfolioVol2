import * as THREE from "three";
import { scene, camera } from "../main";
import { sceneManager } from "../sceneManager.js";
import { createStarfield, removeStarfield } from "../environment/starfield.js";

let textEl, terminalEl;
let uiRemoved = false;
let removedDueToScroll = false; // ⬅️ samma som starfield

export const intro = {
  init() {
    createStarfield();

    // Titel: MY SPACE
    textEl = document.createElement("div");
    textEl.innerText = "MY SPACE";
    textEl.style.cssText = `
      position: fixed;
      top: 30%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 5rem;
      font-family: monospace;
      color: #00ffff;
      text-shadow: 0 0 15px #00ffff;
      opacity: 1;
      transition: opacity 1s ease-in-out;
      z-index: 9999;
      pointer-events: none;
    `;
    document.body.appendChild(textEl);

    // Terminal UI
    terminalEl = document.createElement("div");
    terminalEl.id = "intro-ui";
    terminalEl.innerHTML = `
      <div style="
        position: fixed;
        top: 55%;
        left: 50%;
        transform: translateX(-50%);
        font-size: 1rem;
        color: #66ffff;
        font-family: monospace;
        text-align: center;
        z-index: 9999;
      ">
        Press <strong>[START SCAN]</strong> or use your command center.<br>
        Type <code>scan</code> to begin...
      </div>

      <input id="scan-input" placeholder=">_" style="
        position: fixed;
        top: 62%;
        left: 50%;
        transform: translateX(-50%);
        background: black;
        color: #00ffff;
        border: 1px solid #00ffff;
        font-family: monospace;
        font-size: 1rem;
        padding: 6px 10px;
        z-index: 9999;
        text-align: center;
      " />

      <button id="start-btn" style="
        position: fixed;
        top: 70%;
        left: 50%;
        transform: translateX(-50%);
        background-color: #00ffff;
        color: black;
        font-weight: bold;
        border: none;
        padding: 10px 20px;
        font-size: 1rem;
        font-family: sans-serif;
        cursor: pointer;
        box-shadow: 0 0 10px #00ffff;
        z-index: 9999;
      ">START SCAN // ENTER CORTEX SPACE</button>
    `;
    document.body.appendChild(terminalEl);

    document.getElementById("start-btn").addEventListener("click", () => {
      sceneManager.start("sceneScan");
    });

    document.getElementById("scan-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.value.toLowerCase().includes("scan")) {
        sceneManager.start("sceneScan");
      }
    });

    // Återställ scroll-flaggan
    uiRemoved = false;
    removedDueToScroll = false;
  },

  update(time) {
    const scrollLimit = window.innerHeight;

    // 🧽 Ta bort UI och stoppa animation om vi har scrollat
    if (window.scrollY > scrollLimit && !removedDueToScroll) {
      if (textEl) {
        textEl.remove();
        textEl = null;
      }
      if (terminalEl) {
        terminalEl.remove();
        terminalEl = null;
      }

      removeStarfield();
      removedDueToScroll = true;
      return;
    }

    // ✅ Om vi har scrollat förbi: gör inget mer
    if (removedDueToScroll) return;

    // 🔄 Kamerarörelse bara när vi är kvar i heron
    camera.position.x = Math.sin(time * 0.1) * 5;
    camera.lookAt(0, 0, 0);
  },

  dispose() {
    if (textEl) textEl.remove();
    if (terminalEl) terminalEl.remove();
    removeStarfield();
  }
};
