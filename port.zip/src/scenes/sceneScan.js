import * as THREE from "three";
import { scene, camera } from "../main";
import { sceneManager } from "../sceneManager.js";
import { createStarfield, removeStarfield } from "../environment/starfield.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

let overlay, aim, velocityText, brainModel, exploreBtn, infoBox, aimDisabledText, scanStatus;
let animationFrame = 0;
let currentSpeed = 0;
let targetLocked = false;
let approaching = false;
let scanPulse = 0;
let orbitAngle = 0;

export const sceneScan = {
  init() {
    createStarfield();

    const loader = new GLTFLoader();
    loader.load("/model/Untitled.glb", (gltf) => {
      brainModel = gltf.scene;
      brainModel.scale.set(10, 10, 10);
      brainModel.position.set(0, -30, -800);
      scene.add(brainModel);
    });

    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambient);

    const directional = new THREE.DirectionalLight(0xffffff, 1);
    directional.position.set(0, 50, 100);
    scene.add(directional);

    overlay = document.createElement("div");
    overlay.id = "hud-ui";
    overlay.innerHTML = `
      <div id="scan-status" style="position:fixed;top:5%;left:50%;transform:translateX(-50%);width:320px;
        padding:10px;background:rgba(0,255,255,0.05);border:2px dashed #00ffff;
        color:#00ffff;font-family:monospace;font-size:14px;text-shadow:0 0 4px #00ffff;
        z-index:9999;animation:fadeIn 1s ease-out forwards;">
        <strong>SCANNING SECTOR...</strong>
      </div>
      <div style="position:fixed;top:60%;left:10%;transform:rotate(-10deg);
        width:180px;height:100px;background:rgba(0,255,255,0.03);
        border:1px solid #00ffff;border-radius:8px;z-index:9998;
        animation:fadeIn 1.5s ease-out forwards;">
        <div style="padding:8px;color:#00ffff;font-family:monospace;">
          SIGNAL STRENGTH: 92%<br>OBJECT RANGE: 7200 AU
        </div>
      </div>
      <div style="position:fixed;top:60%;right:10%;transform:rotate(10deg);
        width:180px;height:100px;background:rgba(0,255,255,0.03);
        border:1px solid #00ffff;border-radius:8px;z-index:9998;
        animation:fadeIn 1.8s ease-out forwards;">
        <div style="padding:8px;color:#00ffff;font-family:monospace;">
          STATUS: ACTIVE<br>NEURAL LINK: READY
        </div>
      </div>
      <div style="position:fixed;bottom:5%;left:30%;width:160px;
        background:rgba(0,255,255,0.03);border:1px solid #00ffff;border-radius:6px;
        z-index:9998;animation:fadeIn 2.0s ease-out forwards;">
        <div style="padding:8px;color:#00ffff;font-family:monospace;">
          ENERGY LEVEL: 75%
        </div>
      </div>
      <div style="position:fixed;bottom:5%;right:30%;width:160px;
        background:rgba(0,255,255,0.03);border:1px solid #00ffff;border-radius:6px;
        z-index:9998;animation:fadeIn 2.3s ease-out forwards;">
        <div style="padding:8px;color:#00ffff;font-family:monospace;">
          VELOCITY: <span id="velocity">000</span> KM/H
        </div>
      </div>
      <div id="aim" style="
        position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
        width:80px;height:80px;border:2px solid #00ffff;border-radius:50%;
        box-shadow:0 0 10px #00ffff;z-index:9999;transition:opacity 1s;"></div>
      <div id="aim-disabled" style="
        position:fixed;top:55%;left:50%;transform:translateX(-50%);
        font-family:monospace;color:#00ffff;font-size:14px;
        text-shadow:0 0 6px #00ffff;z-index:9999;opacity:0;transition:opacity 1s;
      ">AIM DISABLED</div>
      <style>
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.8); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes glow {
          0% { text-shadow: 0 0 6px #00ffff; }
          50% { text-shadow: 0 0 12px #00ffff; }
          100% { text-shadow: 0 0 6px #00ffff; }
        }
      </style>
    `;
    document.body.appendChild(overlay);

    aim = document.getElementById("aim");
    aimDisabledText = document.getElementById("aim-disabled");
    velocityText = document.getElementById("velocity");
    scanStatus = document.getElementById("scan-status");

    const speedInterval = setInterval(() => {
      if (currentSpeed < 24) {
        currentSpeed++;
        if (velocityText) velocityText.innerText = currentSpeed.toString().padStart(3, "0");
      } else {
        clearInterval(speedInterval);
      }
    }, 100);

    setTimeout(() => {
      targetLocked = true;
      if (scanStatus) {
        scanStatus.innerHTML = "<strong>TARGET LOCKED!</strong>";
        scanStatus.style.animation = "glow 1s infinite alternate";
      }

      infoBox = document.createElement("div");
      infoBox.innerHTML = `
        <div style="position:fixed;top:20%;right:5%;width:280px;
          background:rgba(0,0,0,0.8);color:#00ffff;font-family:monospace;
          padding:10px;border:1px solid #00ffff;z-index:10000;text-shadow:0 0 6px #00ffff;">
          <strong>ANOMALY DETECTED</strong><br>
          CORTEX SIGNATURE FOUND<br>
          FAR RANGE - LOCKED IN
        </div>
      `;
      document.body.appendChild(infoBox);

      exploreBtn = document.createElement("button");
      exploreBtn.innerText = "Explore";
      exploreBtn.style.cssText = `
        position: fixed;
        bottom: 50%;
        left: 50%;
        transform: translateX(-50%);
        background-color: #00ffff;
        color: black;
        border: none;
        padding: 10px 20px;
        font-size: 1rem;
        font-family: monospace;
        cursor: pointer;
        z-index: 10000;
      `;
      exploreBtn.onclick = () => {
        approaching = true;
        aim.style.opacity = "0";
        aimDisabledText.style.opacity = "1";
        setTimeout(() => {
          aim.remove();
          aimDisabledText.remove();
        }, 2000);
        if (exploreBtn) exploreBtn.remove();
        if (infoBox) infoBox.remove();
      };
      document.body.appendChild(exploreBtn);
    }, 10000);
  },

  update() {
    if (!targetLocked) {
      camera.position.z -= 0.03;
      const t = animationFrame * 0.0025;
      camera.position.x = Math.sin(t) * 12;
      camera.position.y = Math.cos(t * 0.5) * 3;
      camera.lookAt(0, 0, -100);

      const x = 50 + Math.sin(t * 1.5) * 40;
      const y = 50 + Math.cos(t * 1.1) * 25;
      aim.style.left = `${x}%`;
      aim.style.top = `${y}%`;

    } else if (!approaching) {
      aim.style.left = `50%`;
      aim.style.top = `50%`;
      camera.position.x += (0 - camera.position.x) * 0.02;
      camera.position.y += (0 - camera.position.y) * 0.02;
      camera.lookAt(0, -30, -800);

    } else if (approaching && brainModel) {
      const orbitRadius = 40;
      orbitAngle += 0.002;
      const orbitX = Math.sin(orbitAngle) * orbitRadius;
      const orbitZ = Math.cos(orbitAngle) * orbitRadius - 800;

      camera.position.x += (orbitX - camera.position.x) * 0.02;
      camera.position.z += (orbitZ - camera.position.z) * 0.02;
      camera.position.y += (-30 - camera.position.y) * 0.02;
      camera.lookAt(brainModel.position);
    }

    if (brainModel) brainModel.rotation.y += 0.002;

    animationFrame++;
  },

  dispose() {
    const el = document.getElementById("hud-ui");
    if (el) el.remove();
    if (exploreBtn) exploreBtn.remove();
    if (infoBox) infoBox.remove();
    removeStarfield();
    if (brainModel) scene.remove(brainModel);
  }
};
