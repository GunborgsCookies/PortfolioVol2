import * as THREE from "three";
import { scene, camera } from "../main";
import { sceneManager } from "../sceneManager.js";
import { createStarfield, removeStarfield } from "../environment/starfield.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

let cable, brain, dockUI;
let docking = false;
let progress = 0;

export const sceneDock = {
  init() {
    createStarfield();

    // UI
    dockUI = document.createElement("div");
    dockUI.id = "dock-ui";
    dockUI.innerHTML = `
      <div style="position:fixed;top:5%;left:50%;transform:translateX(-50%);color:#00ffff;
        font-family:monospace;font-size:1.5rem;text-shadow:0 0 6px #00ffff;z-index:9999;">
        Ready to Dock with Cortex
      </div>
      <button id="dock-btn" style="position:fixed;top:15%;left:50%;transform:translateX(-50%);
        background:#00ffff;color:black;font-weight:bold;border:none;padding:10px 20px;
        font-family:monospace;font-size:1rem;cursor:pointer;z-index:9999;box-shadow:0 0 8px #00ffff;">
        CONNECT / DOCK
      </button>
    `;
    document.body.appendChild(dockUI);

    document.getElementById("dock-btn").addEventListener("click", () => {
      docking = true;
      document.getElementById("dock-btn").remove();
    });

    // Load real brain model
    const loader = new GLTFLoader();
    loader.load(
      "/model/Untitled.glb",
      (gltf) => {
        brain = gltf.scene;
        brain.scale.set(10, 10, 10);
        brain.position.set(0, 0, -200);
        scene.add(brain);
      },
      undefined,
      (error) => {
        console.error("Failed to load brain model:", error);
      }
    );

    // Cable
    const cableGeo = new THREE.CylinderGeometry(0.1, 0.1, 1, 16);
    const cableMat = new THREE.MeshBasicMaterial({ color: 0x00ffff });
    cable = new THREE.Mesh(cableGeo, cableMat);
    cable.position.set(0, -10, 0);
    scene.add(cable);

    // Light
    const ambient = new THREE.AmbientLight(0xffffff, 0.3);
    scene.add(ambient);

    const directional = new THREE.DirectionalLight(0xffffff, 1);
    directional.position.set(50, 50, 100);
    scene.add(directional);
  },

  update() {
    if (docking && progress < 1) {
      progress += 0.004;

      // Animate cable extension
      cable.scale.set(1, progress * 100, 1);
      cable.position.z = -progress * 100;

      // Smooth camera follow
      camera.position.z = 100 - progress * 150;
      camera.lookAt(new THREE.Vector3(0, 0, -200));

      if (progress >= 1) {
        setTimeout(() => {
          sceneManager.start("sceneSite");
        }, 1200);
      }
    }
  },

  dispose() {
    if (dockUI) dockUI.remove();
    if (brain) scene.remove(brain);
    if (cable) scene.remove(cable);
    removeStarfield();
  }
};
