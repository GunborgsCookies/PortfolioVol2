import * as THREE from "three";
import { scene, camera } from "../main";
import {
  createStarfield,
  removeStarfield,
  getStarPoints
} from "../environment/starfield.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { sceneManager } from "../sceneManager.js";

let warpOverlay;
let brainModel = null;
let stretch = false;
let warpTime = 0;
let speed = 0.05;
let positions = null;

export const sceneApproach = {
  init() {
    createStarfield();
    positions = getStarPoints();

    // 💡 Ljus
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(50, 100, 200);
    scene.add(directionalLight);

    // Overlay
    warpOverlay = document.createElement("div");
    warpOverlay.id = "warp-ui";
    warpOverlay.style.position = "fixed";
    warpOverlay.style.top = "50%";
    warpOverlay.style.left = "50%";
    warpOverlay.style.transform = "translate(-50%, -50%)";
    warpOverlay.style.fontFamily = "monospace";
    warpOverlay.style.fontSize = "2rem";
    warpOverlay.style.color = "#00ffff";
    warpOverlay.style.textShadow = "0 0 6px #00ffff";
    warpOverlay.style.zIndex = "9999";
    warpOverlay.innerText = "WARP INITIATED";
    document.body.appendChild(warpOverlay);

    // Starta warp
    setTimeout(() => {
      stretch = true;
    }, 1000);

    // Ladda modellen efter resan
    setTimeout(() => {
      if (warpOverlay) warpOverlay.remove();

      const loader = new GLTFLoader();
      loader.load(
        "/model/Untitled.glb",
        (gltf) => {
          brainModel = gltf.scene;
          brainModel.scale.set(10, 10, 10);
          brainModel.position.z = -200;
          scene.add(brainModel);
          stretch = false;

          // Dock-knapp
          const dockBtn = document.createElement("button");
          dockBtn.innerText = "DOCK";
          dockBtn.style.cssText = `
            position: fixed;
            top: 70%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #00ffff;
            color: black;
            font-weight: bold;
            border: none;
            padding: 12px 24px;
            font-family: monospace;
            font-size: 1rem;
            cursor: pointer;
            z-index: 9999;
            box-shadow: 0 0 10px #00ffff;
          `;
          dockBtn.addEventListener("click", () => {
            document.body.removeChild(dockBtn);
            sceneManager.start("sceneDock");
          });
          document.body.appendChild(dockBtn);
        },
        undefined,
        (error) => {
          console.error("GLTF load error:", error);
        }
      );
    }, 5000);
  },

  update() {
    warpTime += 0.01;

    if (stretch) {
      camera.position.z -= speed * 80;
      speed += 0.02;

      if (positions) {
        for (let i = 2; i < positions.length; i += 3) {
          positions[i] -= 0.5 + warpTime * 2.5;
        }
      }
    } else if (brainModel) {
      camera.lookAt(brainModel.position);
      const t = Date.now() * 0.0002;
      camera.position.x = Math.sin(t) * 100;
      camera.position.z = Math.cos(t) * 100 + brainModel.position.z;
    }
  },

  dispose() {
    const warpUI = document.getElementById("warp-ui");
    if (warpUI) warpUI.remove();
    if (brainModel) scene.remove(brainModel);
    removeStarfield();
  }
};
