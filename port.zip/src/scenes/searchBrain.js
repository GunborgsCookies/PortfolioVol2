import * as THREE from "three";
import { scene, camera } from "../main";

let brain, loader, brainLight;

export const searchBrain = {
  init() {
    // Skapa en placeholder-hjärna (kan bytas mot glb senare)
    const geometry = new THREE.IcosahedronGeometry(4, 3);
    const material = new THREE.MeshStandardMaterial({
      color: 0xff66cc,
      emissive: 0x441133,
      roughness: 0.3,
      metalness: 0.6
    });

    brain = new THREE.Mesh(geometry, material);
    brain.position.set(0, 0, -80);
    scene.add(brain);

    // Glödande ljus från hjärnan
    brainLight = new THREE.PointLight(0xff66cc, 1.5, 200);
    brainLight.position.copy(brain.position);
    scene.add(brainLight);

    // Text på overlay (kan byggas ut)
    const text = document.createElement("div");
    text.id = "brain-scan";
    text.innerText = "Scanning anomaly...";
    text.style.position = "fixed";
    text.style.top = "20px";
    text.style.left = "50%";
    text.style.transform = "translateX(-50%)";
    text.style.color = "#66ffff";
    text.style.fontSize = "20px";
    text.style.fontFamily = "monospace";
    text.style.zIndex = 9999;
    document.body.appendChild(text);
  },

  update(time) {
    // Kameran åker mot hjärnan
    if (camera.position.z > -60) {
      camera.position.z -= 0.3;
    }

    // Sakta rotation på hjärnan
    if (brain) {
      brain.rotation.y += 0.005;
      brain.rotation.x += 0.002;
    }
  },

  dispose() {
    if (brain) scene.remove(brain);
    if (brainLight) scene.remove(brainLight);

    const text = document.getElementById("brain-scan");
    if (text) text.remove();
  }
};