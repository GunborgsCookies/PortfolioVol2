import * as THREE from "three";
import { scene } from "../main";

let starfield = null;
let nebulaSprites = [];
let removedDueToScroll = false; // ✅ För att ta bort bara en gång

export function createStarfield() {
  const geometry = new THREE.BufferGeometry();
  const vertices = [];
  const colors = [];

  for (let i = 0; i < 10000; i++) {
    const x = THREE.MathUtils.randFloatSpread(2000);
    const y = THREE.MathUtils.randFloatSpread(2000);
    const z = THREE.MathUtils.randFloatSpread(2000);
    vertices.push(x, y, z);

    const color = new THREE.Color();
    color.setHSL(Math.random(), 1.0, 0.8);
    colors.push(color.r, color.g, color.b);
  }

  geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));

  const sprite = new THREE.TextureLoader().load(
    "https://threejs.org/examples/textures/sprites/disc.png"
  );

  const material = new THREE.PointsMaterial({
    map: sprite,
    vertexColors: true,
    size: 2.5,
    transparent: true,
    alphaTest: 0.5,
    opacity: 0.95,
    sizeAttenuation: true,
    blending: THREE.AdditiveBlending
  });

  starfield = new THREE.Points(geometry, material);
  scene.add(starfield);

  // Nebula
  const nebulaTexture = new THREE.TextureLoader().load(
    "https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/lensflare/lensflare0.png"
  );

  const nebulaColors = [0x6622aa, 0x3366ff, 0xff66cc, 0x66ffcc];
  for (let i = 0; i < 12; i++) {
    const color = nebulaColors[i % nebulaColors.length];
    const material = new THREE.SpriteMaterial({
      map: nebulaTexture,
      color,
      opacity: 0.1,
      transparent: true,
      depthWrite: false
    });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(300, 300, 1);
    sprite.position.set(
      THREE.MathUtils.randFloatSpread(1000),
      THREE.MathUtils.randFloatSpread(1000),
      THREE.MathUtils.randFloatSpread(1000)
    );
    scene.add(sprite);
    nebulaSprites.push(sprite);
  }

  removedDueToScroll = false; // återställ om man kör createStarfield igen
}

export function updateStarfield() {
  // 🛑 Ta bort allt när man scrollat förbi hero (första skärmen)
  if (window.scrollY > window.innerHeight && !removedDueToScroll) {
    removeStarfield();
    removedDueToScroll = true;
    return;
  }

  if (!starfield) return;

  starfield.rotation.y += 0.0005;
  nebulaSprites.forEach(sprite => {
    sprite.rotation += 0.0003;
  });
}

export function removeStarfield() {
  if (starfield) scene.remove(starfield);
  starfield = null;

  nebulaSprites.forEach(sprite => scene.remove(sprite));
  nebulaSprites = [];
}

// 🔧 Ny export för sceneApproach
export function getStarPoints() {
  return starfield?.geometry?.attributes?.position?.array;
}
