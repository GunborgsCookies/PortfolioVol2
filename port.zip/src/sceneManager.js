import { intro } from "./scenes/intro.js";
import { sceneScan } from "./scenes/sceneScan.js";
import { sceneApproach } from "./scenes/sceneApproach.js";
import { sceneDock } from "./scenes/sceneDock.js"; // ✅ NY!

const scenes = {
  intro,
  sceneScan,
  sceneApproach,
  sceneDock // ✅ Lägg till här också
};

let currentScene = null;

export const sceneManager = {
  start(id) {
    if (scenes[id]) {
      if (currentScene?.dispose) currentScene.dispose();
      currentScene = scenes[id];
      currentScene.init();
    }
  },

  update(time) {
    if (currentScene?.update) currentScene.update(time);
  }
};
